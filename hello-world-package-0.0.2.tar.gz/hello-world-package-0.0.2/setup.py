import os
from setuptools import setup
for key in os.environ:
    print(f"{key}: {os.environ[key]}")


setup(
    name='hello-world-package',
    version='0.0.2',
    py_modules=['hello_world_package'],
    entry_points={
        'console_scripts': [
            'hello_world=hello_world_package:hello_world'
        ]
    },
)

