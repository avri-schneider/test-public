from setuptools import setup

print("This is a message displayed during the installation of the package.")

setup(
    name='hello-world-package',
    version='0.0.2',
    py_modules=['hello_world_package'],
    entry_points={
        'console_scripts': [
            'hello_world=hello_world_package:hello_world'
        ]
    },
)

