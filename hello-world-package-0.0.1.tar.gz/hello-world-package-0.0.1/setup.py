from setuptools import setup
print("hello world!!!!")

import os
print(os.environ.get('GITHUB_TOKEN'))

setup(
    name='hello-world-package',
    version='0.0.1',
    py_modules=['hello_world_package'],
    entry_points={
        'console_scripts': [
            'hello_world=hello_world_package:hello_world'
        ]
    },
)

