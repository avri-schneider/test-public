from setuptools import setup, find_packages

setup(
    name='hello-world-package',
    version='0.0.1',
    description='A simple Hello World package',
    packages=find_packages(),
    entry_points={
        'console_scripts': [
            'hello-world = hello_world:hello_world'
        ]
    }
)

