from setuptools import setup

def hello_world():
    print("Hello, World!")

setup(
    name='hello-world-package',
    version='0.0.1',
    packages=['hello_world_package'],
    entry_points={
        'console_scripts': [
            'hello-world-package = hello_world_package.__main__:hello_world'
        ]
    },
)

