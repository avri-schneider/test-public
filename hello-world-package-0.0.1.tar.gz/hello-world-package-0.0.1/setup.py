from setuptools import setup

def hello_world():
    print("Hello World")

setup(
    name='hello-world-package',
    version='0.0.1',
    author='Your Name',
    author_email='your_email@example.com',
    description='A package that prints Hello World',
    packages=['hello-world-package'],
    entry_points={
        'console_scripts': []
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    install_requires=[],
    zip_safe=False,
    include_package_data=True,
    cmdclass={
        'install': hello_world
    },
)

