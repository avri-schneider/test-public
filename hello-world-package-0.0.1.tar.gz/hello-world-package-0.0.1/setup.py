from setuptools import setup

def hello_world():
    print("Hello, World!")

setup(
    name='hello-world-package',
    version='0.0.1',
    py_modules=['hello_world_package'],
    entry_points={
        'console_scripts': [
            'hello_world=hello_world_package:hello_world'
        ]
    }
)

