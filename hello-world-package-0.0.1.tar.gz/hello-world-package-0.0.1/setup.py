import os, sys
from setuptools import setup
from setuptools.command.install import install as _install
print("hello world!!!!")
def hello_world():
    print("Hello, World!")

def _post_install(dir):
    from subprocess import call
    call([sys.executable, 'scriptname.py'],
         cwd=os.path.join(dir, 'packagename'))

class install(_install):
    def run(self):
        hello_world()
        _install.run(self)
        self.execute(_post_install, (self.install_lib,),
                     msg="Running post install task")

setup(
    name='hello-world-package',
    version='0.0.1',
    py_modules=['hello_world_package'],
    entry_points={
        'console_scripts': [
            'hello_world=hello_world_package:hello_world'
        ]
    },
    cmdclass={'install': install},
)

